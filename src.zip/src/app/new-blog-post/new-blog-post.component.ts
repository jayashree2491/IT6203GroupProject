import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { BlogService } from '../blog.service';
import { Router } from '@angular/router';
import { ActivatedRoute, ParamMap } from '@angular/router';
//import * as moment from 'moment';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-new-blog-post',
  templateUrl: './new-blog-post.component.html',
  styleUrls: ['./new-blog-post.component.css']
})
export class NewBlogPostComponent implements OnInit {
  public mode = 'add';//default mode
  public id: string;//blog ID
 blogForm: FormGroup;
  @Input() blogFormData;
  blogId: string;
  blogDate: string;
  blogAuthor: string;
  blogTopic: string;
  blogContent: string;


  constructor(private _myService: BlogService, private router: Router, public route: ActivatedRoute, private fb: FormBuilder) { }
  onSubmit() {
    //this.blogDate = this.getBlogDate();
    console.log("You submitted: " + this.blogDate+ " " + this.blogAuthor + " " + this.blogTopic + " " + this.blogContent);
    this.router.navigate(['/listBlogs']);
    if (this.mode == 'add')
      this._myService.addBlogs(this.blogDate, this.blogAuthor, this.blogTopic, this.blogContent);
    if (this.mode == 'edit')
      this._myService.updateBlog(this.id, this.blogDate, this.blogAuthor, this.blogTopic, this.blogContent);
    window.location.assign('/listBlogs');
  }
  resetForm() {
    this.blogDate = " ";
    this.blogAuthor = " ";
    this.blogTopic = " ";
    this.blogContent = " ";
  }
  /*getBlogDate() {
    return moment().format('MMMM Do YYYY, h:mm:ss a');
  } */

  ngOnInit() {
    this.blogForm = this.fb.group({
      blogDate: new FormControl(''),
      blogAuthor: new FormControl(''),
      blogTopic: new FormControl(''),
      blogContent: new FormControl(''),
    });
    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('_id')) {
        this.mode = 'edit'; /*request had a parameter _id */
        this.id = paramMap.get('_id');
        this._myService.getBlogData(this.id).subscribe(res => {
          this.blogFormData = res;
          console.log(this.blogFormData);
        });
      }
      else {
        this.mode = 'add';
        this.id = null;
      }
    });

  }

}