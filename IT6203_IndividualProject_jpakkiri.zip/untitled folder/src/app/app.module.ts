import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ScheduleappointmentComponent } from './scheduleappointment/scheduleappointment.component';
import { PersonalitytestComponent } from './personalitytest/personalitytest.component';
import { HttpClientModule } from '@angular/common/http';
import { AppointmentService } from './appointment.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input'; 
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import {MatDatepickerModule } from '@angular/material/datepicker';
import {MatNativeDateModule } from '@angular/material/core';
import {MatRadioModule} from '@angular/material/radio';
import {MatSelectModule} from '@angular/material/select';
import {MatMenuModule} from '@angular/material/menu';
import {AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './home/home.component';
import { ViewappointmentComponent } from './viewappointment/viewappointment.component';
import { HoursLocationsComponent } from './hours-locations/hours-locations.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { QuestionnarieService } from './questionnarie.service';


@NgModule({
  declarations: [
    AppComponent,
    ScheduleappointmentComponent,
    PersonalitytestComponent,
    HomeComponent,
    ViewappointmentComponent,
    HoursLocationsComponent,
    NotFoundComponent
    
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    MatSelectModule,
    MatMenuModule,
    AppRoutingModule

  ],
  providers: [AppointmentService,QuestionnarieService,PersonalitytestComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
