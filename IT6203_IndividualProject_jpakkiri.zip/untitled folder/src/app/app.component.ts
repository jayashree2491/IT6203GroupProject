import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'KENNESAW STATE UNIVERSITY';
  pageName = "Counseling and Psychological Services";
  date = new Date;
  imageSource = "assets/img/ksuimage.jpeg";
  constructor() { }
  ngOnInit() {
   
  }
}

