import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ScheduleappointmentComponent } from './scheduleappointment/scheduleappointment.component';
import { HomeComponent } from './home/home.component';
import { ViewappointmentComponent } from './viewappointment/viewappointment.component';
import { HoursLocationsComponent } from './hours-locations/hours-locations.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { PersonalitytestComponent } from './personalitytest/personalitytest.component';


const routes: Routes = [
  {path: 'scheduleappointment', component: ScheduleappointmentComponent},
  {path: '', component: HomeComponent},
  {path: 'viewappointment',component:ViewappointmentComponent},
  {path: 'hours-locations', component:HoursLocationsComponent},
  {path: 'editappointment/:_id', component: ScheduleappointmentComponent},
  {path: 'personalitytest',component: PersonalitytestComponent},
  {path: '**', component: NotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
