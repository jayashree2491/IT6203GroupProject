;
import { NotFoundComponent } from './not-found/not-found.component';
import { ListResourcesComponent } from './list-resources/list-resources.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ResourceService } from './resource.service';
import { HttpClientModule } from '@angular/common/http';
import { NewResourceFormComponent } from './new-resource-form/new-resource-form.component';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input'; 
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';

import {MatMenuModule} from '@angular/material/menu';
import {MatDividerModule} from '@angular/material/divider';
import {MatListModule} from '@angular/material/list';
import { MatTableModule } from '@angular/material/table';
import { NavigationMenuComponent } from './navigation-menu/navigation-menu.component';
import { MatIconModule } from '@angular/material/icon';
import { Routes, RouterModule } from '@angular/router';

const appRoutes: Routes = [ {
  path: '',                     
   component: ListResourcesComponent
 },       {
   path: 'addResource',         
   component: NewResourceFormComponent
 },       {
    path: 'editResource/:_id',          
    component: NewResourceFormComponent
  },      {
   path: 'listResources',       
   component: ListResourcesComponent
 },       {
   path: '**',                 
   component: NotFoundComponent
 }
];

@NgModule({
  declarations: [
    AppComponent,
    NewResourceFormComponent,
    NavigationMenuComponent,
    ListResourcesComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    BrowserAnimationsModule,
    FormsModule,
    MatButtonModule,
    MatMenuModule,
    MatDividerModule,
    MatListModule,
    MatTableModule,
    MatIconModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [ResourceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
