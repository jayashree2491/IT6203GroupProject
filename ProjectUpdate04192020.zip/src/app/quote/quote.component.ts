import { Component, OnInit } from '@angular/core';
import { ResourceService } from '../resource.service';
import {Router} from '@angular/router';
import {ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-quote',
  templateUrl: './quote.component.html',
  styleUrls: ['./quote.component.css']
})
export class QuoteComponent implements OnInit {
  public quote;
  constructor(private _myService: ResourceService, private router: Router, public route: ActivatedRoute) { }
  
  onSubmit() {
     this.router.navigate(['/quote']);
  }

  ngOnInit() {
    this.getQuote();
  }
  
getQuote() {
  this._myService.getQuote().subscribe(
     //read data and assign to public variable resources
     data => { this.quote = data},
     err => console.error(err),
     () => console.log('finished loading')
   );
  }
  getUrl () {
    return "url ('/assets/img/photo62699.jpg')";
  }
}
