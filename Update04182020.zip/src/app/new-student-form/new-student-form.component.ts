import { Component, OnInit, Input } from '@angular/core';
import { StudentService } from '../students.service';
import {Router} from '@angular/router';
import {ActivatedRoute, ParamMap } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
@Component({
  selector: 'app-new-student-form',
  templateUrl: './new-student-form.component.html',
  styleUrls: ['./new-student-form.component.css']
})
export class NewStudentFormComponent implements OnInit {
  @Input() firstName: string;
  @Input() lastName: string;
  @Input() email: string;
  @Input() phone: string;
  @Input() gender: string;
  @Input() info: string;






  public mode = 'add'; //default mode
  private id: string; //student ID
  editForm: FormGroup;
  submitted = false;


//initialize the call using StudentService 
constructor(private formBuilder: FormBuilder,private _myService: StudentService ,private router:Router,public route: ActivatedRoute) { }

  ngOnInit(){
    this.route.paramMap.subscribe((paramMap: ParamMap ) => {
      if (paramMap.has('_id'))
        { this.mode = 'edit'; /*request had a parameter _id */ 
          this.id = paramMap.get('_id');
          this.editForm = this.formBuilder.group({
            _id: [],
            firstName: [''],
            lastName: [''],
            email:[''],
            phone:[''],
            gender:[''],
            info:['']
        
            
          });
        
            
            this._myService.getStudentById(this.id).subscribe(data=>{
              console.log(data);
              this.editForm.patchValue(data); //Don't use editForm.setValue() as it will throw console error
            });
        }
      else {this.mode = 'add'
          this.id = null; }
    });

 
  } 


  // get f() { return this.editForm.controls; }

  onSubmit(){
    console.log("You submitted: " + this.firstName + " " + this.lastName);
    
    if(this.mode == 'add')
      this._myService.addStudents(this.firstName ,this.lastName,this.email,this.phone,this.gender,this.info);
       this.router.navigate(['/listMeetup']);

    if(this.mode == 'edit')
       this.submitted = true;
      // console.log(this.editForm.value);
       this._myService.updateStudent(this.editForm.value);
      // console.log("You submitted: " + this.firstName + " " + this.lastName);

      this.router.navigate(['/listMeetup']);
}


}
